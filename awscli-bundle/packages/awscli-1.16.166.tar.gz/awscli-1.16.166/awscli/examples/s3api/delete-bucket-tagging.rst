The following command deletes a tagging configuration from a bucket named ``my-bucket``::

  aws s3api delete-bucket-tagging --bucket my-bucket
