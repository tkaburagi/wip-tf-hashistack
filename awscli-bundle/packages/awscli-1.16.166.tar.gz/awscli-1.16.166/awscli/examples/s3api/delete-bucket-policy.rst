The following command deletes a bucket policy from a bucket named ``my-bucket``::

  aws s3api delete-bucket-policy --bucket my-bucket
